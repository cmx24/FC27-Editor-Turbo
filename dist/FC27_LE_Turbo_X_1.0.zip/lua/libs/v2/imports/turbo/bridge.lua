-- FC 27 LE Turbo - bridge between Live Editor's Lua engine and the Turbo GUI (Turbo.dll).
--
-- Lua -> GUI  (files in <Live Editor>\turbo_output):
--   bridge_meta.json   database meta (GetDBMeta: table/field short names, bit depth, minimum)
--   bridge_state.json  DB / career plugin addresses, career state, in-game date
-- GUI -> Lua:
--   bridge_dll.json    address of the GUI's command mailbox in game memory
--   mailbox            polled on every career-mode event; commands run Turbo modules
--
-- Mailbox layout (allocated by Turbo.dll):
--   +0x00 magic 'TRBO'  +0x04 version  +0x08 command seq  +0x0C ack seq  +0x10 status  +0x14 heartbeat
--   +0x20 command JSON (4096)  +0x1020 result text (4096)
--   +0x2020 game-call block (mailbox version 2, turbogui/src/core/game_calls.h): Lua -> Turbo.dll calls into the
--   game's own code (M.game_call): +0 op, +4 status, +8 seq, +0xC result seq, +0x10 i64 args[4], +0x30 i64 out[2],
--   +0x40 text (512)

-- LAUNCH SAFETY: at game launch only M.arm (pure Lua) and M.load_gui("launch") run. load_gui("launch") loads Turbo.dll,
-- which touches nothing until Live Editor reports "Initial setup done" in its log (or this Lua side runs in game).
-- The bridge itself (M.start: GetDBMeta, GetPlugin, game memory) starts only from turbo_gui_load.lua or on the
-- first career-mode event, when the game is fully running.

local util = require 'imports/turbo/core/util'
local env = require 'imports/turbo/core/env'
local log = require 'imports/turbo/core/log'
local game = require 'imports/turbo/core/game'
local trace = require 'imports/turbo/core/trace'

local M = {}

local MAGIC = 0x4F425254
local OFF_VERSION, OFF_SEQ, OFF_ACK, OFF_STATUS, OFF_HEARTBEAT = 0x04, 0x08, 0x0C, 0x10, 0x14
local OFF_CMD, OFF_RESULT, TEXT_SIZE = 0x20, 0x1020, 0x1000
-- game-call block (mailbox version 2)
local CALL_VERSION = 2
local CALL_OP, CALL_STATUS, CALL_SEQ, CALL_RESULT_SEQ = 0x2020, 0x2024, 0x2028, 0x202C
local CALL_ARGS, CALL_OUT, CALL_TEXT, CALL_TEXT_SIZE = 0x2030, 0x2050, 0x2060, 0x200
local CALL_IDLE, CALL_OK, CALL_FAILED, CALL_QUEUED = 0, 1, -1, 2
M.CALL_OP_JOB_OFFER = 1
M.CALL_OP_STANDINGS_REFRESH = 2  -- args: svm, managers, comm service, ifce (turbogui/src/core/standings_refresh.h)
-- args: action (core/moves.lua LIST_ACTION), player id, comm service, the player's club; outputs: contract status
-- before / after (turbogui/src/core/transfer_list.h)
M.CALL_OP_TRANSFER_LIST = 10
-- args: comm service, code | months << 8, pid | wage << 32, from | to << 32; outputs: from_ok, to_ok (1 / 0 / -1 not read)
-- (turbogui/src/core/player_move.h)
M.CALL_OP_PLAYER_MOVE = 11
-- args: comm service, code (1 create, 9 check only), the payload's seq, playerid; the row itself is in
-- turbo_output\turbo_player_create.json; outputs: written mask (-1 = the call is off), IsPlayerInTeam(pid, final team)
-- (turbogui/src/core/player_create.h). OFF unless turbo_output\call_player_create_on.txt exists.
M.CALL_OP_PLAYER_CREATE = 12
-- player_morale (op 13, turbogui/src/core/player_morale.h): args = comm, code (1 very happy, 2 value, 3 count stale, 9 check), pid,
-- value; outputs = total read back (-2 = the player has no morale record), level read back 0..5 (code 3: stale count, records)
M.CALL_OP_PLAYER_MORALE = 13
-- squad_role (op 14, turbogui/src/core/squad_role.h): args = comm, code (1 set, 2 ensure an entry with the game's own role, 3 count
-- stale, 4 remove a stale entry, 9 check), pid, role 1..5 (code 1); outputs = role read back (-2 = no entry, none created; code 3 the
-- stale count, code 4 1 / 0 removed), how (codes 1 / 2: 0 written, 1 entry created, 2 unchanged, -1 nothing done) or the used entries
M.CALL_OP_SQUAD_ROLE = 14
M.PLAYER_CREATE_PAYLOAD = "turbo_player_create.json"
M.PLAYER_CREATE_OPT_IN = "call_player_create_on.txt"
M.CALL_OP_REVEAL = 3            -- args: PlayerDataRevealManager, mode (0 player / 1 team), id, manager table (core/reveal.h)
M.CALL_OP_MANAGER_RULES = 4      -- args: sub-op, manager address, value, user team (turbogui/src/core/manager_rules.h)

-- bridge_dll.json is stamped by the DLL every ~2 s while it runs. A file older than this is left over from an
-- earlier game session: its mailbox address means nothing in this process and is never read.
local DLL_FRESH_SECONDS = 15

-- Event ids that mean "the database may have been replaced"
local RELOAD_EVENTS = { "POST_LOAD_PREPARE", "ENTERED_HUB_FIRST_TIME", "CAREER_TYPE_SELECTED", "INITIAL_USER_ADDED" }

TURBO_STATE = TURBO_STATE or { listeners = {} }
TURBO_STATE.bridge = TURBO_STATE.bridge or {
    seq = 0, db_gen = 0, load_gen = 0, last_state = nil, meta_written = false,
    mailbox = nil, mailbox_session = nil, next_dll_check = 0, heartbeat = 0,
    session = string.format("%X", math.floor(os.time() % 0x7FFFFFFF)),
    gui_loaded = false, reload_ids = nil,
}
local S = TURBO_STATE.bridge
S.load_gen = S.load_gen or 0  -- a bridge state kept from an older Turbo in this Lua session has none

local function json()
    local ok, j = pcall(require, 'imports/external/json')
    if ok and type(j) == "table" then return j end
    return nil
end

-- Folder for bridge files: <root>\turbo_output when writable, else <root>
function M.dir()
    local root = env.le_root()
    if not root then return nil end
    local out = util.join(root, "turbo_output")
    if util.write_file(util.join(out, ".bridge_write_test"), "ok") then
        os.remove(util.join(out, ".bridge_write_test"))
        return out
    end
    return root
end

local function hex(v)
    if type(v) ~= "number" or v <= 0 then return "0x0" end
    return string.format("0x%X", math.tointeger(v) or 0)
end

local function plugin(enum_name)
    pcall(require, 'imports/services/enums')
    local id = _G[enum_name]
    if type(GetPlugin) ~= "function" or type(id) ~= "number" then return 0 end
    local ok, addr = pcall(GetPlugin, id)
    if ok and type(addr) == "number" then return math.tointeger(addr) or 0 end
    return 0
end

-- ---------------------------------------------------------------- Lua -> GUI
-- GetDBMeta() may return plain Lua tables or C++ objects (userdata). Live Editor's own t3db code only indexes it
-- (meta.shortname_name_tables_map[short], fld_meta[short].name / .depth / .min), so Turbo never relies on its Lua type.
local function desc_entry(d)
    local name = util.index(d, "name")
    if type(name) ~= "string" or name == "" then return nil end
    return { name = name, depth = tonumber(util.index(d, "depth")) or 0, min = tonumber(util.index(d, "min")) or 0 }
end

-- 1) Iterate the meta maps (Lua tables, or userdata containers that support pairs)
local function meta_by_iteration(meta)
    local names, fields = {}, {}
    local ok1 = util.each(util.index(meta, "shortname_name_tables_map"), function(short, name)
        if type(short) == "string" and type(name) == "string" then names[short] = name end
    end)
    local ok2 = util.each(util.index(meta, "field_desc_map"), function(tshort, fmap)
        if type(tshort) ~= "string" then return end
        local t = {}
        util.each(fmap, function(fshort, d)
            if type(fshort) == "string" then t[fshort] = desc_entry(d) end
        end)
        if next(t) ~= nil then fields[tshort] = t end
    end)
    if not ok1 or not ok2 then return nil, nil end
    return names, fields
end

-- 2) The tables in game memory, loaded by Live Editor's own t3db library (LE.db), which looks each short name up in the
-- meta by indexing only. Used when the meta cannot be iterated.
local function meta_from_le_db()
    if type(LE) ~= "table" or type(LE.db) ~= "table" or type(LE.db.Reset) ~= "function" then return nil, nil end
    local ok = pcall(function() LE.db:Reset() end)
    if not ok or type(LE.db.tables) ~= "table" then return nil, nil end
    local names, fields = {}, {}
    for name, tbl in pairs(LE.db.tables) do
        local short = type(tbl) == "table" and tbl.shortname or nil
        if type(name) == "string" and type(short) == "string" and short ~= "" then
            names[short] = name
            local t = {}
            if type(tbl.fields) == "table" then
                for _, fld in pairs(tbl.fields) do
                    if type(fld) == "table" and type(fld.shortname) == "string" then t[fld.shortname] = desc_entry(fld.fld_desc) end
                end
            end
            fields[short] = t
        end
    end
    return names, fields
end

function M.write_meta(force)
    if S.meta_written and not force then return true end
    if type(GetDBMeta) ~= "function" then return false, "GetDBMeta is not available" end
    local ok, meta = pcall(GetDBMeta)
    if not ok then return false, "GetDBMeta failed: " .. tostring(meta) end
    if not util.is_object(meta) then return false, "GetDBMeta returned " .. type(meta) end
    local names, fields = meta_by_iteration(meta)
    local source = "GetDBMeta"
    if not names or next(names) == nil or next(fields) == nil then
        names, fields = meta_from_le_db()
        source = "LE.db"
    end
    if not names or next(names) == nil or next(fields) == nil then
        return false, "the database meta is empty (database not loaded yet?)"
    end
    local j = json()
    local dir = M.dir()
    if not j or not dir then return false, "json library or output folder missing" end
    local okj, text = pcall(j.encode, { session = S.session, shortname_name_tables_map = names, field_desc_map = fields })
    if not okj then return false, "cannot encode meta: " .. tostring(text) end
    local okw, werr = util.write_file(util.join(dir, "bridge_meta.json"), text)
    if not okw then return false, tostring(werr) end
    S.meta_written = true
    S.meta_source = source
    return true
end

-- Player names. playernames.name is a compressed text field (field type 13) in FC 27: Turbo.dll cannot read it from
-- memory, but Live Editor's documented GetDBTableRows decodes it (43,000 names in ~0.3 s). The names go to
-- bridge_names.txt: first line "#turbo-names <session> <count>", then one "nameid<TAB>name" line per name.
M.NAME_TABLES = { "playernames" }

local function row_value(row, key)
    local cell = util.index(row, key)
    if util.is_object(cell) then cell = util.index(cell, "value") end
    return cell
end

function M.write_names()
    local get_rows = _G["GetDBTableRows"]
    if type(get_rows) ~= "function" then return false, "GetDBTableRows is not available" end
    local dir = M.dir()
    if not dir then return false, "output folder missing" end
    local out, count = {}, 0
    for _, tname in ipairs(M.NAME_TABLES) do
        local ok, rows = pcall(get_rows, tname)
        if ok and util.is_object(rows) then
            for i = 1, util.len(rows) do
                local row = util.index(rows, i)
                local id = tonumber(row_value(row, "nameid"))
                local name = row_value(row, "name")
                if id and type(name) == "string" and name ~= "" then
                    out[#out + 1] = string.format("%d\t%s", math.tointeger(id) or 0, (name:gsub("[\t\r\n]", " ")))
                    count = count + 1
                end
            end
        end
    end
    if count == 0 then return false, "no player names returned by GetDBTableRows" end
    local text = string.format("#turbo-names %s %d\n", S.session, count) .. table.concat(out, "\n") .. "\n"
    local okw, werr = util.write_file(util.join(dir, "bridge_names.txt"), text)
    if not okw then return false, tostring(werr) end
    S.names_count = count
    pcall(M.write_commentary_names)
    return true, count
end

-- Commentary names ("callnames"): commentarynames.commentarystring is compressed text too. The ids and their text go to
-- bridge_commentary.txt: "#turbo-commentary <session> <count>", then "commentaryid<TAB>text" lines. Which of these
-- ids are spoken in the commentary language the game has loaded is decided on the GUI side (per-language lists).
function M.write_commentary_names()
    local get_rows = _G["GetDBTableRows"]
    if type(get_rows) ~= "function" then return false, "GetDBTableRows is not available" end
    local dir = M.dir()
    if not dir then return false, "output folder missing" end
    local ok, rows = pcall(get_rows, "commentarynames")
    if not ok or not util.is_object(rows) then return false, "commentarynames not readable" end
    local out, count = {}, 0
    for i = 1, util.len(rows) do
        local row = util.index(rows, i)
        local id = tonumber(row_value(row, "commentaryid"))
        local text = row_value(row, "commentarystring")
        if id and type(text) == "string" and text ~= "" then
            out[#out + 1] = string.format("%d\t%s", math.tointeger(id) or 0, (text:gsub("[\t\r\n]", " ")))
            count = count + 1
        end
    end
    if count == 0 then return false, "no commentary names" end
    local body = string.format("#turbo-commentary %s %d\n", S.session, count) .. table.concat(out, "\n") .. "\n"
    local okw, werr = util.write_file(util.join(dir, "bridge_commentary.txt"), body)
    if not okw then return false, tostring(werr) end
    S.commentary_count = count
    return true, count
end

-- force = retry now even if the last attempt failed less than a minute ago
local function try_write_names(force)
    if not force and S.names_retry_at and os.time() < S.names_retry_at then return false, "retry later" end
    local okc, ok, res = pcall(M.write_names)
    if not okc then ok, res = false, tostring(ok) end
    if ok then
        S.names_retry_at = nil
    else
        S.names_retry_at = os.time() + 60
        log.warn("bridge_names.txt not written: %s", tostring(res))
    end
    return ok, res
end

-- write_meta, remembering why it failed (shown by the GUI through bridge_state.json and reported by bridge.start)
local function try_write_meta(force)
    local okc, ok, err = pcall(M.write_meta, force)
    if not okc then ok, err = false, tostring(ok) end
    if ok then
        S.meta_error = nil
        return true
    end
    err = tostring(err or "unknown error")
    if S.meta_error ~= err then log.warn("bridge_meta.json not written: %s", err) end
    -- the GUI is told only while it has no bridge_meta.json from this session to work with
    if not S.meta_written then S.meta_error = err end
    return false, err
end

-- Effective Turbo settings (turbo_config.json + gui_settings.json) shown by the GUI
function M.set_settings(cfg)
    if type(cfg) ~= "table" then return end
    local a = type(cfg.auto) == "table" and cfg.auto or {}
    local fm = type(a.form_morale) == "table" and a.form_morale or {}
    local ps = type(a.pap_playstyles) == "table" and a.pap_playstyles or {}
    local sr = type(a.squad_role) == "table" and a.squad_role or {}
    S.settings = {
        dry_run = type(cfg.turbo) == "table" and cfg.turbo.dry_run == true,
        auto = {
            form_morale = { enabled = fm.enabled == true, form = tonumber(fm.form) or 0,
                            morale = tonumber(fm.morale) or 0, fitness = tonumber(fm.fitness) or 0 },
            pap_playstyles = { enabled = ps.enabled == true },
            squad_role = { enabled = sr.enabled == true, rule = sr.rule == "role" and "role" or "age", rule_role = tonumber(sr.rule_role) or 3 },
        },
    }
end

local function transfer_budget()
    local ok, tb = pcall(require, 'imports/turbo/features/transfer_budget')
    if not ok then return nil end
    return (tb.current())
end

-- Tools this Live Editor build cannot run (fixed for a Live Editor build, so worked out once)
local function unavailable_tools()
    if S.unavailable == nil then
        local ok, caps = pcall(require, 'imports/turbo/core/caps')
        local okc, list = false, nil
        if ok then okc, list = pcall(caps.unavailable) end
        S.unavailable = (okc and type(list) == "table") and list or {}
    end
    return S.unavailable
end

-- Moves Turbo makes itself in this Live Editor build (worked out once)
local function turbo_made_tools()
    if S.turbo_made == nil then
        local ok, caps = pcall(require, 'imports/turbo/core/caps')
        local okc, list = false, nil
        if ok then okc, list = pcall(caps.turbo_made) end
        S.turbo_made = (okc and type(list) == "table") and list or {}
    end
    return S.turbo_made
end

-- The career's StandingsViewManager (FCE manager type 108) and the manager table it sits in. Turbo.dll re-requests the
-- standings through that manager after a live table edit, so FC 27's Standings screen shows the edit
-- (turbogui/src/core/standings_refresh.h, docs/re/standings-ui-path.md). Only in a career, only through the checked
-- walk of core/mem.lua (nothing is read without the GUI's memory map); 0 when unknown.
local function standings_view_manager(in_cm)
    if not in_cm then return 0, 0 end
    local okm, mem = pcall(require, 'imports/turbo/core/mem')
    if not okm or type(mem) ~= "table" then return 0, 0 end
    pcall(require, 'imports/career_mode/enums')
    local id = _G["ENUM_FCEGameModesFCECareerModeStandingsViewManager"]
    if type(id) ~= "number" then id = 108 end
    local okt, managers = pcall(mem.manager_table)
    local oks, svm = pcall(mem.manager, id)
    return (oks and math.type(svm) == "integer") and svm or 0, (okt and math.type(managers) == "integer") and managers or 0
end
M._standings_view_manager = standings_view_manager

-- Job security / sack flags of the user's manager for the Turbo window (features/manager_rules.lua state(): checked
-- reads only, nothing is called); nil outside a career or without the memory map
local function manager_rules_state(in_cm)
    if not in_cm then return nil end
    local okm, mr = pcall(require, 'imports/turbo/features/manager_rules')
    if not okm or type(mr) ~= "table" then return nil end
    local ok, st = pcall(mr.state)
    if ok and type(st) == "table" then return st end
    return nil
end

function M.collect_state()
    local in_cm = game.in_cm()
    local d = in_cm and game.current_date() or nil
    local svm, managers = standings_view_manager(in_cm)
    return {
        settings = S.settings,
        session = S.session,
        meta_error = S.meta_error,
        names_count = S.names_count or 0,
        commentary_count = S.commentary_count or 0,
        le_version = tostring(LE_VERSION or ""),
        db_service = hex(plugin("ENUM_djb2Database_CLSS") - 8),
        comm_service = hex(plugin("ENUM_djb2FeFceGMCommServiceInterface_CLSS")),
        ifce = hex(plugin("ENUM_djb2IFCEInterface_CLSS")),
        svm = hex(svm),
        managers = hex(managers),
        in_cm = in_cm,
        user_team = in_cm and game.user_team_id() or 0,
        transfer_budget = in_cm and transfer_budget() or nil,
        unavailable = unavailable_tools(),
        turbo_made = turbo_made_tools(),
        -- transfers / releases go through the game's own move (Turbo.dll player_move, core/moves.lua): the GUI's notes say so
        game_moves = type(_G.TurboPlayerMove) == "function",
        date = d and { year = d.year, month = d.month, day = d.day } or nil,
        -- outcome of the last game call that finished after being queued (M.game_call): the GUI shows it as a toast
        game_call = S.game_call,
        manager_rules = manager_rules_state(in_cm),
        -- tactics channel E's gate G2 (M.track_phase): "hub" / "prematch" / "match" / "unknown", when it last changed (diagnostics),
        -- and when a save last started
        match_phase = S.match_phase or "unknown",
        phase_t = S.phase_t,
        save_t = S.save_t,
        -- gameplay tuning (turbogui core/tuning.h): when Lua last saw the prematch event (os.time()). The phase goes hub -> prematch ->
        -- hub (about 0.5 s) -> match at kick-off: Turbo.dll's hub writes wait 5 s after it, also when its 0.5 s poll missed the prematch
        prematch_t = S.prematch_t,
        -- gameplay tuning's boot moment (turbogui core/tuning.h kBootReportSeconds): Lua's report of the main menu = a state written
        -- while no career is loaded (the bridge started there by turbo_gui_load.lua, or a career left); Turbo.dll writes the boot moment
        -- only within 60 s of it, never without it (Lua sees no event outside career mode: no Kick-Off / skill game can be told apart later)
        front_end_t = (not in_cm) and os.time() or nil,
        -- Team Management open (ENTERING_TEAM_MANAGEMENT seen, no LEAVING_TEAM_MANAGEMENT or other phase event since): channel E's G2
        -- refuses then (Edit Tactic's screen holds its own values; leaving it may ask to save the team sheet, and Yes autosaves the career)
        team_mgmt = S.team_mgmt == true,
    }
end

local function same_settings(a, b)
    local j = json()
    if not j then return true end
    local ok1, ea = pcall(j.encode, a or {})
    local ok2, eb = pcall(j.encode, b or {})
    return ok1 and ok2 and ea == eb
end

local function same_state(a, b)
    if not a or not b then return false end
    if a.settings ~= b.settings and not same_settings(a.settings, b.settings) then return false end
    if a.db_service ~= b.db_service or a.in_cm ~= b.in_cm or a.user_team ~= b.user_team then return false end
    if a.svm ~= b.svm or a.managers ~= b.managers or a.ifce ~= b.ifce then return false end
    if a.transfer_budget ~= b.transfer_budget then return false end
    if a.match_phase ~= b.match_phase or a.phase_t ~= b.phase_t or a.save_t ~= b.save_t or a.prematch_t ~= b.prematch_t then return false end
    if a.team_mgmt ~= b.team_mgmt then return false end
    if a.meta_error ~= b.meta_error then return false end
    if (a.game_call and a.game_call.seq or 0) ~= (b.game_call and b.game_call.seq or 0) then return false end
    if not same_settings(a.manager_rules, b.manager_rules) then return false end
    local ad, bd = a.date, b.date
    if (ad == nil) ~= (bd == nil) then return false end
    if ad and (ad.year ~= bd.year or ad.month ~= bd.month or ad.day ~= bd.day) then return false end
    return true
end

-- Write bridge_state.json when something changed (or force). reload = the database may have moved.
-- db_gen changes whenever the GUI should re-read the database (also when the manager changes club, or on a "refresh"
-- command); load_gen only when a career was (re)loaded, entered or left: a reload event (load_event), in_cm flipping
-- or another database service. The GUI writes kept edits again once per load_gen (turbogui ui_reapply.cpp): FC 27
-- reloads teamkits and playernamemap from its base data at a career load, not when the manager changes club.
function M.write_state(force, reload, load_event)
    local st = M.collect_state()
    local prev = S.last_state
    local loaded = load_event or not prev or prev.db_service ~= st.db_service or prev.in_cm ~= st.in_cm
    local structural = reload or loaded or prev.user_team ~= st.user_team
    if not force and not structural and same_state(prev, st) then return true end
    if structural then S.db_gen = S.db_gen + 1 end
    if loaded then S.load_gen = (S.load_gen or 0) + 1 end
    S.seq = S.seq + 1
    st.seq = S.seq
    st.db_gen = S.db_gen
    st.load_gen = S.load_gen
    local j = json()
    local dir = M.dir()
    if not j or not dir then return false, "json library or output folder missing" end
    local ok, text = pcall(j.encode, st)
    if not ok then return false, tostring(text) end
    local okw, werr = util.write_file(util.join(dir, "bridge_state.json"), text)
    if not okw then return false, tostring(werr) end
    S.last_state = st
    return true
end

-- ---------------------------------------------------------------- GUI -> Lua
local function find_mailbox()
    local dir = M.dir()
    local j = json()
    if not dir or not j then return nil end
    local path = util.join(dir, "bridge_dll.json")
    if not util.file_exists(path) then return nil end
    local ok, data = pcall(j.decode, util.read_file(path) or "")
    if not ok or type(data) ~= "table" or type(data.mailbox) ~= "string" then return nil end
    -- Never touch memory on the word of a stale file (a previous game session wrote it)
    local updated = tonumber(data.updated)
    if not updated or math.abs(os.time() - updated) > DLL_FRESH_SECONDS then return nil end
    local addr = tonumber((data.mailbox:gsub("^0[xX]", "")), 16)
    if not addr or addr < 0x10000 then return nil end
    addr = math.tointeger(addr)
    if MEMORY:ReadInt(addr) ~= MAGIC then return nil end
    return addr, data.session
end

-- Address of the Turbo GUI's mailbox in this game process (nil without a fresh bridge_dll.json); used by core/mem.lua
-- to find the readable-memory map
function M.mailbox_address()
    if S.mailbox and MEMORY:ReadInt(S.mailbox) == MAGIC then return S.mailbox end
    local addr = find_mailbox()
    if addr then S.mailbox = addr end
    return addr
end

local function read_text(addr)
    local s = MEMORY:ReadString(addr, TEXT_SIZE)
    if type(s) ~= "string" then return "" end
    return (s:match("^[^%z]*"))
end

-- Execute one decoded command; returns ok, text
function M.execute(cmd)
    if type(cmd) ~= "table" then return false, "bad command" end
    local TURBO = require 'imports/turbo/turbo'
    if cmd.op == "ping" then return true, "pong" end
    if cmd.op == "boot" then
        local enabled = TURBO.boot()
        return true, "automatic features: " .. (#enabled > 0 and table.concat(enabled, ", ") or "none")
    end
    if cmd.op == "run" then
        if type(cmd.module) ~= "string" then return false, "module missing" end
        local overrides = type(cmd.overrides) == "table" and cmd.overrides or nil
        return TURBO.run(cmd.module, overrides, { silent = true })
    end
    if cmd.op == "refresh" then
        local okm, merr = try_write_meta(true)
        try_write_names(true)
        M.write_state(true, true)
        if not okm then return false, "bridge_meta.json not written: " .. tostring(merr) end
        return true, "bridge refreshed"
    end
    return false, "Turbo does not know this command (" .. tostring(cmd.op) .. "): update Turbo so the window and the Lua side match"
end

local function clock()
    if type(os) == "table" and type(os.clock) == "function" then return os.clock() end
    return 0
end

-- Check the mailbox; runs at most one pending command. Returns true when a command ran.
-- force = look for bridge_dll.json now instead of at most once a second
-- Finds the GUI's mailbox through a fresh bridge_dll.json (at most once a second unless forced). True when connected.
function M.connect_mailbox(force)
    if S.mailbox then return true end
    local t = clock()
    if not force and t < S.next_dll_check then return false end
    S.next_dll_check = t + 1.0
    local addr, session = find_mailbox()
    if not addr then return false end
    S.mailbox, S.mailbox_session = addr, session
    log.info("connected to Turbo GUI mailbox at 0x%X", addr)
    return true
end

function M.poll_mailbox(force)
    if not M.connect_mailbox(force) then return false end
    local mb = S.mailbox
    if MEMORY:ReadInt(mb) ~= MAGIC then
        S.mailbox = nil
        return false
    end
    S.heartbeat = (S.heartbeat + 1) % 0x7FFFFFFF
    MEMORY:WriteInt(mb + OFF_HEARTBEAT, S.heartbeat)
    local seq = MEMORY:ReadInt(mb + OFF_SEQ)
    if seq == MEMORY:ReadInt(mb + OFF_ACK) then return false end
    -- a command is running (its game code posted a career-mode event that got here): it is consumed, never run twice
    if S.cmd_running then return false end

    local ok, text
    local j = json()
    local okd, cmd = pcall(j.decode, read_text(mb + OFF_CMD))
    if not okd then
        ok, text = false, "command is not valid JSON"
    else
        S.cmd_running = seq
        local okx, r1, r2 = pcall(M.execute, cmd)
        S.cmd_running = nil
        if okx then ok, text = r1 == true, tostring(r2 or "") else ok, text = false, "error: " .. tostring(r1) end
    end
    if #text > TEXT_SIZE - 1 then text = text:sub(1, TEXT_SIZE - 1) end
    MEMORY:WriteString(mb + OFF_RESULT, text)
    MEMORY:WriteInt(mb + OFF_STATUS, ok and 1 or 0)
    MEMORY:WriteInt(mb + OFF_ACK, seq)
    return true
end

-- ---------------------------------------------------------------- events
local function reload_ids()
    if S.reload_ids then return S.reload_ids end
    local events = require 'imports/turbo/core/events'
    S.reload_ids = events.resolve_set(RELOAD_EVENTS)
    return S.reload_ids
end

-- Match phase and save start for Turbo.dll's tactics channel E (turbogui/src/core/team_sheet.h, gate G2: your club's live tactic is
-- written in the career hub only, never while a match is set up or played, nor while a save runs). "unknown" until the first event of
-- one of these lists since Turbo started (the event that starts the bridge counts too). Leaving the pre-match screen without playing keeps
-- "prematch" until the next hub event (Turbo.dll writes in "hub" only).
M.PHASE_EVENTS = {
    hub = { "POST_LOAD_PREPARE", "ENTERED_HUB_FIRST_TIME", "DAY_PASSED", "USER_MATCH_COMPLETED", "USER_INTERNATIONAL_MATCH_COMPLETED",
            "POST_MATCH_REPORTS_DISPLAYED" },
    prematch = { "ABOUT_TO_ENTER_PREMATCH" },
    match = { "TEAMS_READY_FOR_USER_MATCH", "ABOUT_TO_ENTER_A_MATCH", "ABOUT_TO_SIM_OVER_A_MATCH", "ABOUT_TO_ENTER_QUICK_SIM",
              "ABOUT_TO_ENTER_INTERACTIVE_SIM", "ABOUT_TO_ENTER_PLAY_HIGHLIGHTS", "ABOUT_TO_ENTER_PLAY_FULL_MATCH_SIM", "MATCH_RESTARTED" },
}
M.SAVE_EVENTS = { "PREPARE_FOR_SAVE", "PREPARE_FOR_FIRST_SAVE" }
-- Team Management (where Edit Tactic lives): open from ENTERING_TEAM_MANAGEMENT until LEAVING_TEAM_MANAGEMENT or any phase event above
M.TEAM_MGMT_EVENTS = { enter = "ENTERING_TEAM_MANAGEMENT", leave = "LEAVING_TEAM_MANAGEMENT" }

local function phase_ids()
    if S.phase_ids and S.team_mgmt_ids then return S.phase_ids, S.save_ids end
    local events = require 'imports/turbo/core/events'
    local ids = {}
    for phase, names in pairs(M.PHASE_EVENTS) do
        for id in pairs((events.resolve_set(names))) do ids[id] = phase end
    end
    S.phase_ids = ids
    S.save_ids = events.resolve_set(M.SAVE_EVENTS)
    S.team_mgmt_ids = { enter = events.resolve(M.TEAM_MGMT_EVENTS.enter), leave = events.resolve(M.TEAM_MGMT_EVENTS.leave) }
    return S.phase_ids, S.save_ids
end

-- Called for every real career-mode event before the state is written (and for the event that starts the bridge)
function M.track_phase(event_id)
    local ids, saves = phase_ids()
    local phase = ids[event_id]
    if phase and phase ~= S.match_phase then
        S.match_phase = phase
        S.phase_t = os.time()
    end
    -- every prematch event (also one that does not change the phase): the tuning profile's hub writes wait after it
    if phase == "prematch" then S.prematch_t = os.time() end
    if saves[event_id] then S.save_t = os.time() end
    local tm = S.team_mgmt_ids or {}
    if tm.enter and event_id == tm.enter then S.team_mgmt = true
    elseif (tm.leave and event_id == tm.leave) or phase then S.team_mgmt = false end
end

-- Turbo.dll's synthetic event (core/events.lua SYNTHETIC_ID): the GUI has a command waiting. Only the mailbox and the
-- native pump run; the state files, name lists and reload logic belong to real career-mode events.
local function on_synthetic_event()
    if S.autoload_pending then return end  -- the bridge is not running yet: nothing can be waiting
    local okp, perr = pcall(M.poll_mailbox, true)
    if not okp then log.warn("bridge mailbox: %s", tostring(perr)) end
    local okg, gerr = pcall(M.pump_native)
    if not okg then log.warn("bridge native pump: %s", tostring(gerr)) end
    -- the GUI also sends this event every 250 ms while it loads pictures in the background and is shown (1.1.1,
    -- ui/preload.h): a short slice each time, so the game and the Turbo window keep running smoothly
    local okl, lerr = pcall(function() return (require 'imports/turbo/core/legacy').pump(M.IMAGE_SLICE_SYNTHETIC) end)
    if not okl then log.warn("bridge images: %s", tostring(lerr)) end
end

-- seconds of image exports per synthetic event (career-mode events keep a quarter of a second)
M.IMAGE_SLICE_SYNTHETIC = 0.08

-- Match crash guard (features/squad_role.lua repair_entries): every player of your club needs a PlayerStatusManager entry
-- or the game's match load reads a null entry. Checked at each career load and on the days / match build-up after it,
-- until the table is complete; cheap when nothing is missing. Off with turbo_output\squad_status_repair_off.txt.
-- With Turbo.dll's squad_role call (TurboSquadRole) the entries come from the game's own AddPlayer (stale ones go through its
-- Remove); after the load event the game picks the role itself (its squad ranking, as for a signing without a contract role:
-- the role the Squad screen already showed for him). At the load event itself Turbo gives the role by age (no ranking is
-- computed while the career is still being set up). Without the call: memory, role by age.
M.STATUS_REPAIR_EVENTS = { "POST_LOAD_PREPARE", "ENTERED_HUB_FIRST_TIME", "DAY_PASSED", "ABOUT_TO_ENTER_PREMATCH" }

local function status_repair_ids()
    if S.status_repair_ids then return S.status_repair_ids end
    S.status_repair_ids = (require 'imports/turbo/core/events').resolve_set(M.STATUS_REPAIR_EVENTS)
    return S.status_repair_ids
end

function M.repair_squad_status(event_id)
    local root = env.le_root()
    if root and util.file_exists(util.join(util.join(root, "turbo_output"), "squad_status_repair_off.txt")) then
        S.status_repair_pending = false
        return nil, "off"
    end
    local role = require 'imports/turbo/features/squad_role'
    -- the role by age reads the players table: only built when a player is missing an entry
    local by_age = nil
    local function role_of(pid)
        if by_age == nil then
            local ok, f = pcall(function()
                return (require 'imports/turbo/features/team_mass').role_by_age(role.club_players(game.user_team_id()))
            end)
            by_age = ok and f or false
        end
        return by_age and by_age(pid) or nil
    end
    local events = require 'imports/turbo/core/events'
    local at_load = event_id ~= nil and event_id == events.resolve("POST_LOAD_PREPARE")
    S.status_repair_t = os.time()   -- before the run: an error is throttled too (2.1)
    local added, text, left = role.repair_entries(role_of, false, { prefer_game_role = not at_load })
    -- 2.0.4: until every player has an entry the guard runs again on every career-mode event (at most once a second, see
    -- on_career_event), not only on the load / day / match build-up events
    S.status_repair_pending = (added == nil) or ((left or 0) > 0)
    -- 2.1: the same failure three times in a row -> retry only on the guard's own events (load, hub, day, match build-up), so a
    -- shortfall the guard cannot fix costs nothing on every other event and never runs inside a game transaction for long
    if S.status_repair_pending and text == S.status_repair_last then S.status_repair_same = (S.status_repair_same or 0) + 1 else S.status_repair_same = 0 end
    -- logged when something was added or the reason changes (not on every day); players still without an entry: a warning
    if added and added > 0 then
        if (left or 0) > 0 then log.warn("match crash guard: %s", text) else log.info("match crash guard: %s", text) end
    elseif text ~= S.status_repair_last then
        if S.status_repair_pending then log.warn("match crash guard: %s", tostring(text)) else log.info("match crash guard: %s", tostring(text)) end
    end
    S.status_repair_last = text
    return added, text
end

-- true when the guard should run on this event: its own events, and any event (once a second) while players are missing
local function status_repair_due(event_id)
    if status_repair_ids()[event_id] then return true end
    if (S.status_repair_same or 0) >= 3 then return false end
    return S.status_repair_pending ~= false and os.time() - (S.status_repair_t or 0) >= 1
end

function M.on_career_event(event_id)
    if (require 'imports/turbo/core/events').is_synthetic(event_id) then return on_synthetic_event() end
    if S.autoload_pending then
        -- gui.autoload: first career-mode event = the game is fully running; start the bridge now (its match phase is kept: often the
        -- career load's POST_LOAD_PREPARE, the hub)
        S.autoload_pending = false
        pcall(M.track_phase, event_id)
        local ok, err = pcall(M.start, S.cfg)
        if not ok then log.error("Turbo GUI start failed: %s", tostring(err)) end
        return
    end
    if not S.meta_written then try_write_meta(false) end
    local reload = reload_ids()[event_id] == true
    if reload or not S.names_count then try_write_names() end
    pcall(M.track_phase, event_id)
    -- (write_state also connects the mailbox on the way, through core/mem.lua's map lookup)
    local okw, werr = pcall(M.write_state, false, reload, reload)
    if not okw then log.warn("bridge state: %s", tostring(werr)) end
    -- queued native work for the game thread (Turbo.dll's game-thread dispatcher, src/win/game_hooks.cpp): this
    -- handler runs on the thread that posts career-mode events, so pumping here runs it on the game's own thread.
    -- Pumped BEFORE the mailbox commands: the pump tells the DLL which thread is the game thread, so a game call made
    -- by a command below runs at once instead of being queued for the next event.
    pcall(M.connect_mailbox)
    local okg, gerr = pcall(M.pump_native)
    if not okg then log.warn("bridge native pump: %s", tostring(gerr)) end
    local okn, installed = pcall(M.install_natives)
    if not okn then log.warn("bridge natives: %s", tostring(installed)) end
    -- the match crash guard after the pump and the natives: its game calls (TurboSquadRole) then run at once on this thread.
    -- A career load makes it pending again (a new career's table); pending also covers the first events after the game starts,
    -- when the bridge was started by the event itself (2.0.4: the load event used to be skipped then)
    if reload then S.status_repair_pending = true; S.status_repair_same = 0 end
    -- a game call the pump just finished is collected first, so the guard's own game calls are not refused as "still queued" (2.1)
    if S.call_pending then pcall(M.check_game_call) end
    if status_repair_due(event_id) then
        local okq, qerr = pcall(M.repair_squad_status, event_id)
        if not okq then log.warn("match crash guard: %s", tostring(qerr)) end
    end
    local okc, finished = pcall(M.check_game_call)
    if not okc then log.warn("bridge game call: %s", tostring(finished)) end
    -- a kept "unsackable" (features/manager_rules.lua) is switched on again once per game session
    if S.natives_installed then
        local okr, rerr = pcall(function() return (require 'imports/turbo/features/manager_rules').reapply() end)
        if not okr then log.warn("manager rules: %s", tostring(rerr)) end
    end
    -- OVR-1 repair (features/repair_ovr1.lua): writes only with the opt-in file turbo_output\repair_ovr1_on.txt and
    -- never with the kill switch repair_ovr1_off.txt; the module checks both itself and logs what it did or why not
    local oko, ovr_mod = pcall(require, 'imports/turbo/features/repair_ovr1')
    if oko and type(ovr_mod) == "table" and type(ovr_mod.on_career_event) == "function" then
        local okv, verr = pcall(ovr_mod.on_career_event, event_id)
        if not okv then log.warn("repair_ovr1: %s", tostring(verr)) end
    elseif not S.repair_ovr1_load_warned then
        S.repair_ovr1_load_warned = true
        log.warn("repair_ovr1 module not loaded: %s", tostring(ovr_mod))
    end
    -- natives just installed (the capability list changed) or a queued game call finished: publish it now
    if (okn and installed == true) or (okc and finished == true) then
        local okw2, werr2 = pcall(M.write_state, true, false)
        if not okw2 then log.warn("bridge state: %s", tostring(werr2)) end
    end
    local okp, perr = pcall(M.poll_mailbox)
    if not okp then log.warn("bridge mailbox: %s", tostring(perr)) end
    -- game images the Turbo window asked for (core/legacy.lua): a quarter of a second per event
    local okl, lerr = pcall(function() return (require 'imports/turbo/core/legacy').pump(0.25) end)
    if not okl then log.warn("bridge images: %s", tostring(lerr)) end
end

-- Runs Turbo.dll's exported turbo_game_pump() on this thread (the game thread that posts career-mode events): queued
-- work from host::run_on_game_thread executes here when the DLL has no per-frame game hook. The function is looked up
-- once through package.loadlib and only while the GUI's mailbox is live (so nothing is loaded that is not running);
-- a failed lookup is retried at most every PUMP_RETRY_EVENTS events. Returns true when the pump ran.
local PUMP_RETRY_EVENTS = 60

-- An exported function of the running Turbo.dll (package.loadlib), cached in S[slot]; false = not found (retried
-- every PUMP_RETRY_EVENTS calls, for an older Turbo.dll without that export). Only while the mailbox is live.
local function native_export(slot, symbol)
    -- cached under S.native_<slot>: a slot named like a state field (game_call = the last call outcome) must not collide
    if not S.mailbox then return nil end
    local f = S["native_" .. slot]
    if type(f) == "function" then return f end
    local tries = (S["native_" .. slot .. "_tries"] or 0) + 1
    S["native_" .. slot .. "_tries"] = tries
    if f == false and (tries % PUMP_RETRY_EVENTS) ~= 1 then return nil end
    local path = M.gui_path()
    if not path or type(package) ~= "table" or type(package.loadlib) ~= "function" then
        S["native_" .. slot] = false
        return nil
    end
    f = package.loadlib(path, symbol)
    if type(f) ~= "function" then
        S["native_" .. slot] = false
        return nil
    end
    S["native_" .. slot] = f
    log.info("Turbo.dll export %s found", symbol)
    return f
end

function M.pump_native()
    local pump = native_export("pump", "turbo_game_pump")
    if not pump then return false end
    pump()
    S.pumps = (S.pumps or 0) + 1
    return true
end

-- ---------------------------------------------------------------- game calls (Turbo.dll runs game code for Lua)
-- Is the mailbox new enough for the call block (Turbo.dll 0.4.1+)?
local function call_block_available()
    local mb = S.mailbox
    if not mb then return false, "the Turbo GUI is not running" end
    if MEMORY:ReadInt(mb + OFF_VERSION) < CALL_VERSION then
        return false, "this Turbo.dll is older than Turbo's Lua side (no game-call block in its mailbox)"
    end
    return true
end

local function read_call_result(mb)
    local status = MEMORY:ReadInt(mb + CALL_STATUS)
    local rseq = MEMORY:ReadInt(mb + CALL_RESULT_SEQ)
    local out0 = MEMORY:ReadQword(mb + CALL_OUT)
    local out1 = MEMORY:ReadQword(mb + CALL_OUT + 8)
    local text = MEMORY:ReadString(mb + CALL_TEXT, CALL_TEXT_SIZE)
    if type(text) ~= "string" then text = "" end
    text = text:match("^[^%z]*")
    return status, rseq, out0, out1, text
end

-- Ask Turbo.dll to run a game call. op: M.CALL_OP_*; args: up to four integers (addresses / ids).
-- Returns status ("ok", "failed", "queued" or "unavailable"), text, out0, out1.
-- "queued": the call runs when the dispatcher next runs on the game thread (the next career-mode event); the outcome
-- is then logged and published in bridge_state.json (game_call) by M.check_game_call.
function M.game_call(op, args, label)
    local okb, why = call_block_available()
    if not okb then return "unavailable", why end
    local f = native_export("game_call", "turbo_game_call")
    if not f then return "unavailable", "this Turbo.dll has no turbo_game_call export (update Turbo)" end
    if S.call_pending then
        return "failed", string.format("game call #%d (%s) is still queued; wait for the next career-mode event",
            S.call_pending.seq, tostring(S.call_pending.label))
    end
    local mb = S.mailbox
    S.call_seq = (S.call_seq or 0) + 1
    local seq = S.call_seq
    MEMORY:WriteInt(mb + CALL_STATUS, CALL_IDLE)
    for i = 0, 3 do
        local v = args and args[i + 1] or 0
        if math.type(v) ~= "integer" then v = math.tointeger(v) or 0 end
        MEMORY:WriteQword(mb + CALL_ARGS + i * 8, v)
    end
    MEMORY:WriteInt(mb + CALL_OP, op)
    MEMORY:WriteInt(mb + CALL_SEQ, seq)
    f()
    local status, rseq, out0, out1, text = read_call_result(mb)
    if rseq ~= seq then return "failed", "Turbo.dll did not answer the game call (result #" .. tostring(rseq) .. ")" end
    if status == CALL_OK then return "ok", text, out0, out1 end
    if status == CALL_QUEUED then
        S.call_pending = { seq = seq, op = op, label = label or "game call" }
        return "queued", text
    end
    -- the outputs go along: a call that failed late (player_move's read-backs) still reports what it read
    return "failed", text ~= "" and text or "the game call failed without a message", out0, out1
end

-- A queued game call finished? Logs it and publishes it for the GUI (bridge_state.json game_call).
function M.check_game_call()
    local p = S.call_pending
    if not p or not S.mailbox then return false end
    local status, rseq, out0, out1, text = read_call_result(S.mailbox)
    if rseq ~= p.seq or status == CALL_QUEUED or status == CALL_IDLE then return false end
    S.call_pending = nil
    local ok = status == CALL_OK
    S.game_call = { seq = p.seq, ok = ok, text = string.format("%s: %s", tostring(p.label), text), out0 = out0, out1 = out1 }
    if ok then log.info("game call %s: %s", tostring(p.label), text) else log.warn("game call %s failed: %s", tostring(p.label), text) end
    return true
end

-- TurboPlayerMorale(code, pid, value) -> ok, text, status, total, level: one player of the user's club to the game's own "very happy"
-- level for his emotion type (code 1) or a value 0..120 (code 2) through PlayerMoraleManager::SetTotalMorale (Turbo.dll op 13,
-- turbogui/src/core/player_morale.h); code 3 counts the stale morale records (total = stale count, level = records), 9 checks only.
-- Code 1 creates a missing morale record first (text "record created"); total -2 = no record and none created (creation off by
-- turbo_output\call_player_morale_create_off.txt, not resolved, failed, or codes 2 / 9). status "off" when the call is unavailable / switched off.
function M.player_morale(code, pid, value)
    local c, p, v = math.tointeger(code) or 0, math.tointeger(pid) or 0, math.tointeger(value) or 0
    if c ~= 1 and c ~= 2 and c ~= 3 and c ~= 9 then
        return false, "this Turbo does not know that morale action: update Turbo", "failed"
    end
    if c ~= 3 and (p <= 0 or p > 0x7FFFFFFF) then return false, "player id must be a positive number", "failed" end
    if c == 2 and (v < 0 or v > 120) then return false, "morale " .. tostring(value) .. " is out of range (0 to 120)", "failed" end
    if c ~= 2 then v = 0 end
    if c == 3 then p = 0 end
    local comm = plugin("ENUM_djb2FeFceGMCommServiceInterface_CLSS")
    local status, text, out0, out1 = M.game_call(M.CALL_OP_PLAYER_MORALE, { comm, c, p, v },
        string.format("morale player %d (code %d)", p, c))
    if status == "unavailable" then return false, "player_morale: off (" .. tostring(text) .. ")", "off" end
    if status == "failed" and type(text) == "string" and text:find("player_morale: off", 1, true) then return false, text, "off" end
    if status == "ok" then return true, text, status, math.tointeger(out0), math.tointeger(out1) end
    if status == "queued" then return true, text, status end
    return false, text, status, math.tointeger(out0), math.tointeger(out1)
end

-- TurboSquadRole(code, pid, role) -> ok, text, status, out0, out1: the squad role entry of one player of the user's club through the
-- game's own PlayerStatusManager functions (Turbo.dll op 14, turbogui/src/core/squad_role.h; features/squad_role.lua). Codes: 1 set the
-- role (an entry is created with the game's AddPlayer when he has none), 2 an entry with the game's own role when he has none, 3 count
-- the entries of players no longer at the club, 4 remove such an entry (the game's Remove), 9 read. out0 / out1 as M.CALL_OP_SQUAD_ROLE
-- says. status "off" when the call is unavailable / switched off: nothing was called (Lua keeps its memory path).
function M.squad_role(code, pid, role)
    local c, p, r = math.tointeger(code) or 0, math.tointeger(pid) or 0, math.tointeger(role) or 0
    if c ~= 1 and c ~= 2 and c ~= 3 and c ~= 4 and c ~= 9 then
        return false, "unknown squad_role code " .. tostring(code) .. " (1 set, 2 ensure entry, 3 count stale, 4 remove stale, 9 check)", "failed"
    end
    if c ~= 3 and (p <= 0 or p > 0x7FFFFFFF) then return false, "player id must be a positive number", "failed" end
    if c == 1 and (r < 1 or r > 5) then return false, "squad role " .. tostring(role) .. " is out of range (1 Crucial to 5 Prospect)", "failed" end
    if c ~= 1 then r = 0 end
    if c == 3 then p = 0 end
    local comm = plugin("ENUM_djb2FeFceGMCommServiceInterface_CLSS")
    local status, text, out0, out1 = M.game_call(M.CALL_OP_SQUAD_ROLE, { comm, c, p, r }, string.format("squad role player %d (code %d)", p, c))
    if status == "unavailable" then return false, "squad_role: off (" .. tostring(text) .. ")", "off" end
    -- an older Turbo.dll without op 14 answers "unknown game call op": the same as off
    if status == "failed" and type(text) == "string" and (text:find("squad_role: off", 1, true) or text:find("unknown game call op", 1, true)) then
        return false, text, "off"
    end
    if status == "ok" then return true, text, status, math.tointeger(out0), math.tointeger(out1) end
    if status == "queued" then return true, text, status end
    return false, text, status, math.tointeger(out0), math.tointeger(out1)
end

-- TurboPlayerCreate(code, payload) -> ok, text, status, written, in_team: a new player through the game's own database INSERT
-- (Turbo.dll op 12, turbogui/src/core/player_create.h, docs/re/created_players.md): the squad screens, the player search, morale and
-- the contract see him at once. payload = { playerid, team, months, wage, players = { col = int }, names = { firstname = "" ... },
-- link = { form = 3 } }; code 1 create, 9 check only. status "off" = the call is not available (no opt-in file, the DLL says off or
-- does not know op 12): NOTHING was called and the caller keeps its database path. Integers and strings only: a float with a
-- fraction, a non-string name or a name over 44 bytes is refused here (the DLL refuses them too).
M.PLAYER_CREATE_MAX_NAME = 44

local function int_or_nil(v)
    if math.type(v) == "integer" then return v end
    if math.type(v) == "float" then return math.tointeger(v) end
    return nil
end

function M.player_create(code, payload)
    local c = math.tointeger(code) or 0
    if c ~= 1 and c ~= 9 then return false, "this Turbo does not know that player-creation action: update Turbo", "failed" end
    if type(payload) ~= "table" or type(payload.players) ~= "table" then return false, "player_create: the payload has no players row", "failed" end
    local pid = int_or_nil(payload.playerid) or 0
    if pid <= 0 or pid >= 460000 then return false, "player id " .. tostring(payload.playerid) .. " is out of range (1 to 459999)", "failed" end
    local dir = M.dir()
    if not dir then return false, "player_create: off (no turbo_output folder)", "off" end
    if not util.file_exists(util.join(dir, M.PLAYER_CREATE_OPT_IN)) then
        return false, "player_create: off (opt-in: create turbo_output\\" .. M.PLAYER_CREATE_OPT_IN .. ")", "off"
    end
    local j = json()
    if not j then return false, "player_create: off (json library missing)", "off" end
    local doc = { playerid = pid, team = int_or_nil(payload.team) or 0, months = int_or_nil(payload.months) or 0,
                  wage = int_or_nil(payload.wage) or 0, players = {} }
    for k, v in pairs(payload.players) do
        local iv = int_or_nil(v)
        if type(k) ~= "string" or iv == nil then
            return false, string.format("players.%s is %s: the game's INSERT takes integers only", tostring(k),
                math.type(v) == "float" and ("a float (" .. tostring(v) .. ")") or type(v)), "failed"
        end
        doc.players[k] = iv
    end
    doc.players.playerid = pid
    if type(payload.names) == "table" then
        local names = {}
        for k, v in pairs(payload.names) do
            if type(v) ~= "string" then return false, "names." .. tostring(k) .. " is not a string", "failed" end
            if #v > M.PLAYER_CREATE_MAX_NAME then
                return false, string.format("names.%s is %d bytes long (at most %d)", tostring(k), #v, M.PLAYER_CREATE_MAX_NAME), "failed"
            end
            if v ~= "" then names[k] = v end
        end
        if next(names) ~= nil then doc.names = names end   -- an empty table would be written as a JSON array
    end
    if type(payload.link) == "table" and next(payload.link) ~= nil then
        doc.link = {}
        for k, v in pairs(payload.link) do
            local iv = int_or_nil(v)
            if iv == nil then return false, "link." .. tostring(k) .. " is not an integer", "failed" end
            doc.link[k] = iv
        end
    end
    S.create_seq = (S.create_seq or 0) + 1
    doc.seq = S.create_seq
    local okj, text = pcall(j.encode, doc)
    if not okj then return false, "player_create: the payload cannot be encoded: " .. tostring(text), "failed" end
    local okw, werr = util.write_file(util.join(dir, M.PLAYER_CREATE_PAYLOAD), text)
    if not okw then return false, "player_create: " .. M.PLAYER_CREATE_PAYLOAD .. " not written: " .. tostring(werr), "failed" end
    S.last_create_payload = doc
    local comm = plugin("ENUM_djb2FeFceGMCommServiceInterface_CLSS")
    local status, rtext, out0, out1 = M.game_call(M.CALL_OP_PLAYER_CREATE, { comm, c, doc.seq, pid },
        string.format("%s player %d (team %d)", c == 9 and "check new" or "create", pid, doc.team))
    local function flag(v)
        v = math.tointeger(v)
        if v == 1 then return true elseif v == 0 then return false end
        return nil
    end
    if status == "unavailable" then return false, "player_create: off (" .. tostring(rtext) .. ")", "off" end
    -- out[0] = -1: the DLL did not run it (off, or an older Turbo.dll without op 12): nothing was called
    if status == "failed" and math.tointeger(out0) == -1 then return false, tostring(rtext), "off" end
    if status == "ok" then return true, rtext, status, math.tointeger(out0), flag(out1) end
    if status == "queued" then return true, rtext, status end
    return false, rtext, status, math.tointeger(out0), flag(out1)
end

-- Lua-callable natives backed by Turbo.dll's game calls. Defined as globals once the export is found, so
-- core/caps.lua (and env.api) see them like Live Editor's own functions and the GUI lights the buttons up.
--   TurboJobOfferCreate(jobmarket_address, teamid) -> ok, message, status ("ok" | "queued" | "failed")
function M.install_natives()
    if S.natives_installed then return false end   -- true only on the first install (the caller rewrites the state)
    if not S.mailbox then return false end
    local okb = call_block_available()
    if not okb then return false end
    if not native_export("game_call", "turbo_game_call") then return false end
    _G.TurboJobOfferCreate = function(jmm, teamid)
        local a = math.tointeger(jmm) or 0
        local t = math.tointeger(teamid) or 0
        local status, text = M.game_call(M.CALL_OP_JOB_OFFER, { a, t }, string.format("job offer from team %d", t))
        if status == "ok" or status == "queued" then return true, text, status end
        return false, text, status
    end
    --   TurboStandingsRefresh() -> ok, message, status: the game's StandingsViewManager re-requests the live standings
    --   (after a table edit the Standings screen shows the new rows); the DLL finds the manager itself when the walk
    --   here gives nothing
    _G.TurboStandingsRefresh = function()
        local svm, managers = standings_view_manager(game.in_cm())
        local comm, ifce = plugin("ENUM_djb2FeFceGMCommServiceInterface_CLSS"), plugin("ENUM_djb2IFCEInterface_CLSS")
        local status, text = M.game_call(M.CALL_OP_STANDINGS_REFRESH, { svm, managers, comm, ifce }, "standings refresh")
        if status == "ok" or status == "queued" then return true, text, status end
        return false, text, status
    end
    --   TurboTransferList(action, playerid, club) -> ok, message, status, status before, status after: the game's own
    --   Transfer Hub actions (add to the transfer / loan list, remove from the lists, read the list status) for one of
    --   your players (core/moves.lua M.list checks the player first; the DLL checks again against the game)
    _G.TurboTransferList = function(action, playerid, club)
        local a = math.tointeger(action) or 0
        local p = math.tointeger(playerid) or 0
        local c = math.tointeger(club) or 0
        local comm = plugin("ENUM_djb2FeFceGMCommServiceInterface_CLSS")
        local names = { "transfer list", "loan list", "unlist", "unlist (transfer list)", "unlist (loan list)", "list status" }
        local status, text, before, after = M.game_call(M.CALL_OP_TRANSFER_LIST, { a, p, comm, c },
            string.format("%s player %d", names[a] or ("list action " .. a), p))
        if status == "ok" or status == "queued" then return true, text, status, before, after end
        return false, text, status
    end
    --   TurboPlayerMove(code, pid, from, to, months, wage) -> ok, message, status, from_ok, to_ok: the game's own
    --   TeamUtil::PlayerMoved (code 1, + AddContractRecord for an arrival at your club with months > 0), its release
    --   (code 2: ContractTerminationManager::ReleasePlayer for your club, PlayerMoved to Free Agents for any other) or the
    --   whole validation chain without calling anything (code 9). from_ok / to_ok are the game's IsPlayerInTeam read-backs
    --   (true / false, nil = not read). core/moves.lua M.transfer / M.release use it (turbogui/src/core/player_move.h).
    _G.TurboPlayerMove = function(code, pid, from, to, months, wage)
        local c, p = math.tointeger(code) or 0, math.tointeger(pid) or 0
        local f, t = math.tointeger(from) or 0, math.tointeger(to) or 0
        local mo, w = math.tointeger(months) or 0, math.tointeger(wage) or 0
        -- the DLL refuses malformed words; out-of-range values are refused here so the packing never truncates one
        local INT32 = 0x7FFFFFFF
        local bad
        if c ~= 1 and c ~= 2 and c ~= 9 then bad = "this Turbo does not know that player-move action: update Turbo"
        elseif p <= 0 or p > INT32 then bad = "player id must be a positive number"
        elseif f <= 0 or f > INT32 or t < 0 or t > INT32 then bad = "team ids must be positive numbers"
        elseif mo < 0 or mo > 120 then bad = "contract length " .. tostring(months) .. " months is out of range (0 to 120)"
        elseif w < 0 or w > 10000000 then bad = "wage " .. tostring(wage) .. " is out of range (0 to 10,000,000)" end
        if bad then return false, bad, "failed" end
        local comm = plugin("ENUM_djb2FeFceGMCommServiceInterface_CLSS")
        local names = { [1] = "move", [2] = "release", [9] = "check move" }
        local args = { comm, c | (mo << 8), p | (w << 32), f | (t << 32) }
        local status, text, out0, out1 = M.game_call(M.CALL_OP_PLAYER_MOVE, args,
            string.format("%s player %d (%d -> %d)", names[c], p, f, t))
        local function flag(v)
            v = math.tointeger(v)
            if v == 1 then return true elseif v == 0 then return false end
            return nil
        end
        if status == "ok" then return true, text, status, flag(out0), flag(out1) end
        if status == "queued" then return true, text, status end
        return false, text, status, flag(out0), flag(out1)
    end
    --   TurboRevealPlayerData(pdrm_address, mode, id) -> ok, message, status, out0, out1: the game's own
    --   PlayerDataRevealManager marks one player (mode 0, id = player id) or every player of a club (mode 1, id = team
    --   id) fully scouted, so the Player Bio and the GTN show the true attributes and potential (core/reveal.h).
    --   pdrm 0 = the manager the DLL captured from the game's own events. The manager table goes along for the
    --   slot-78 cross-check (0 when unknown: the DLL skips it).
    _G.TurboRevealPlayerData = function(pdrm, mode, id)
        local a = math.tointeger(pdrm) or 0
        local m = math.tointeger(mode) or 0
        local i = math.tointeger(id) or 0
        local managers = 0
        local okm, memmod = pcall(require, 'imports/turbo/core/mem')
        if okm and type(memmod) == "table" and memmod.map_available() then
            local okt, tbl = pcall(memmod.manager_table)
            if okt and math.type(tbl) == "integer" then managers = tbl end
        end
        local status, text, out0, out1 = M.game_call(M.CALL_OP_REVEAL, { a, m, i, managers },
            string.format("reveal %s %d", m == 1 and "team" or "player", i))
        if status == "ok" or status == "queued" then return true, text, status, out0, out1 end
        return false, text, status, out0, out1
    end
    --   TurboManagerRules(sub, address, value, team) -> ok, message, status, out0, out1: job security / unsackable
    --   (features/manager_rules.lua; the sub-ops of turbogui/src/core/manager_rules.h)
    _G.TurboManagerRules = function(sub, addr, value, team)
        local args = { math.tointeger(sub) or 0, math.tointeger(addr) or 0, math.tointeger(value) or 0, math.tointeger(team) or 0 }
        local status, text, out0, out1 = M.game_call(M.CALL_OP_MANAGER_RULES, args, string.format("manager rules (sub-op %d)", args[1]))
        if status == "ok" or status == "queued" then return true, text, status, out0, out1 end
        return false, text, status
    end
    --   TurboPlayerCreate(code, payload) -> ok, text, status, written, in_team (M.player_create above; features/create_player.lua)
    _G.TurboPlayerCreate = M.player_create
    --   TurboPlayerMorale(code, pid, value) -> ok, text, status, total, level (M.player_morale; features/team_mass.lua)
    _G.TurboPlayerMorale = M.player_morale
    --   TurboSquadRole(code, pid, role) -> ok, text, status, out0, out1 (M.squad_role; features/squad_role.lua, the match crash guard)
    _G.TurboSquadRole = M.squad_role
    -- Live Editor's missing natives (cAddPlayerToTransferList & co.) on top of it: its own wrappers work again
    local okm, moves = pcall(require, 'imports/turbo/core/moves')
    local le_names = (okm and type(moves) == "table") and moves.install_le_natives() or {}
    env.reset_api_cache()   -- wrappers that were unavailable because their c-native was missing are usable now
    S.natives_installed = true
    S.unavailable = nil   -- caps changed: bridge_state.json lists job_offer / the list moves / reveal / manager_rules as available from now on
    log.info("Turbo natives installed: TurboJobOfferCreate, TurboStandingsRefresh, TurboTransferList, TurboPlayerMove, TurboRevealPlayerData, TurboManagerRules, TurboPlayerCreate, TurboPlayerMorale, TurboSquadRole (Turbo.dll game calls)%s",
        #le_names > 0 and ("; Live Editor natives: " .. table.concat(le_names, ", ")) or "")
    return true
end

-- ---------------------------------------------------------------- GUI loader
function M.gui_path()
    local root = env.le_root()
    if not root then return nil end
    return util.join(util.join(root, "turbo"), "Turbo.dll")
end

-- Load Turbo.dll into the game process through Lua's package.loadlib. Returns ok, message.
-- mode "launch" (lua\autorun, the game is starting): Turbo.dll waits until Live Editor reports "Initial setup done" in its
-- log or this Lua side runs in game. mode "now" (default: turbo_gui_load.lua, career event): the game is running.
-- The mode is handed over in turbo_output\turbo_gui_load.json, written right before the DLL is loaded.
function M.load_gui(mode)
    if S.gui_loaded then return true, "Turbo GUI already loaded" end
    mode = mode == "launch" and "launch" or "now"
    local path = M.gui_path()
    if not path or not util.file_exists(path) then return false, "Turbo.dll not found at " .. tostring(path) end
    if type(package) ~= "table" or type(package.loadlib) ~= "function" then
        return false, "this Live Editor build has no package.loadlib; run turbo\\TurboInjector.exe instead"
    end
    local dir, j = M.dir(), json()
    if dir and j then
        local okj, text = pcall(j.encode, { mode = mode, time = os.time() })
        if okj then util.write_file(util.join(dir, "turbo_gui_load.json"), text) end
    end
    local f, err = package.loadlib(path, "*")
    if not f then return false, "package.loadlib failed: " .. tostring(err) end
    S.gui_loaded = true
    return true, "Turbo GUI loaded from " .. path
end

-- gui.autoload: remember the settings and start the bridge on the first career-mode event (pure Lua, safe at launch)
function M.arm(cfg)
    local events = require 'imports/turbo/core/events'
    S.cfg = cfg
    if S.started then return end
    S.autoload_pending = true
    events.set_tap("bridge", M.on_career_event)
    trace.step("bridge armed: connects to the game database on the first career-mode event")
end

-- Start the bridge and load the Turbo GUI. Call it only while the game is running (turbo_gui_load.lua).
-- Every step is logged to turbo_output\turbo_boot.log before it runs. Returns ok, message
function M.start(cfg)
    local events = require 'imports/turbo/core/events'
    if type(cfg) ~= "table" then cfg = (require 'imports/turbo/core/config').load() end
    S.cfg = cfg
    S.autoload_pending = false
    S.started = true
    trace.step("bridge.start: begin")
    M.set_settings(cfg)
    events.set_tap("bridge", M.on_career_event)
    local okr, rerr = events.ensure_registered()
    if not okr then log.warn("cannot register career events: %s", tostring(rerr)) end
    trace.step("bridge.start: writing bridge_meta.json (GetDBMeta)")
    local ok_m, merr = try_write_meta(true)
    trace.step("bridge.start: bridge_meta.json " .. (ok_m and ("written from " .. tostring(S.meta_source)) or ("NOT written: " .. tostring(merr))))
    trace.step("bridge.start: writing bridge_names.txt (GetDBTableRows playernames)")
    local ok_n, nres = try_write_names(true)
    trace.step("bridge.start: bridge_names.txt " .. (ok_n and ("written, " .. tostring(nres) .. " names") or ("NOT written: " .. tostring(nres))))
    trace.step("bridge.start: writing bridge_state.json (GetPlugin)")
    local okc, ok_s, serr = pcall(M.write_state, true, false)
    if not okc then ok_s, serr = false, tostring(ok_s) end
    trace.step("bridge.start: bridge_state.json " .. (ok_s and "written" or ("NOT written: " .. tostring(serr))))
    -- (no OVR-1 repair at start: features/repair_ovr1.lua runs on career events only, and only with its opt-in file)
    trace.step("bridge.start: loading turbo\\Turbo.dll (package.loadlib)")
    local ok, msg = M.load_gui()
    trace.step("bridge.start: load_gui returned " .. tostring(ok) .. " - " .. tostring(msg))
    if ok then log.info("%s", msg) else log.warn("Turbo GUI not loaded: %s", msg) end
    if not ok then return false, msg end
    if not ok_m then
        return false, msg .. "\nBut the game database could not be read: " .. tostring(merr)
            .. "\nSee turbo_output\\turbo_boot.log; send it with Live Editor's log."
    end
    if not ok_s then
        return false, msg .. "\nBut bridge_state.json could not be written: " .. tostring(serr)
    end
    return true, msg .. "\nGame database shared with the Turbo GUI (" .. tostring(S.meta_source) .. ")."
end

return M
